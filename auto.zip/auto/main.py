# Bot Devs Radfx2 @aSBSsSa CH :@aSBSsSa
# Requier Bot Modules 
import pyromod
import asyncio 


# Requier Config
from Config import app


asyncio.run(app.run())


