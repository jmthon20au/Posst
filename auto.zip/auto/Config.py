# Bot Config File 
# Requier Bot Modules 
from pyrogram import Client , enums
import os 
# Requier Database Modules Class 
from Utils.database import Database


# Bot Config
class config:
    API_KEY : str = "6418845303:AAFNx_TT6oRMUv8lLhMpeqAmTO_L1516ymY" # The API key or Bot Token
    API_HASH: str = "ee89a5d9626d197efc39ef0783c913c0" # UsrBot Api Hash
    API_ID  : int = 20769091 # User Bot Api Id
    SUDO    : int = 6454550864 # Sudo Id
 


# Check Bot DIrctory
if not os.path.exists('./.session'): # Sesisons FIle 
    os.mkdir('./.session')


if not os.path.exists('./database'): #  Databesas FIle 
    os.mkdir('./database')


# Get Database 
database = Database()

# Temp status 
temp = {'broadcast':False}

# Start Pyrogram Client
app = Client(
    name="./.session/rad", 
    bot_token=config.API_KEY, 
    api_hash=config.API_HASH,
    api_id=config.API_ID, 
    plugins=dict(root="Plugins"), 
    parse_mode=enums.ParseMode.DEFAULT
)

